// ---------- Small helpers ----------
const $ = (selector, root = document) => root.querySelector(selector)

// Course names and descriptions come from the database, so always escape them
// before putting them into HTML.
function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])
}

const wholeMoney = new Intl.NumberFormat(LOCALE, { style: 'currency', currency: CURRENCY, maximumFractionDigits: 0 })
const exactMoney = new Intl.NumberFormat(LOCALE, { style: 'currency', currency: CURRENCY })
const dateFormat = new Intl.DateTimeFormat(LOCALE, { day: 'numeric', month: 'short', year: 'numeric' })

function isFree(price) {
  return Number(price) === 0
}

function formatPrice(price) {
  const n = Number(price)
  if (n === 0) return 'Free'
  return (Number.isInteger(n) ? wholeMoney : exactMoney).format(n)
}

function formatDate(value) {
  return value ? dateFormat.format(new Date(value)) : ''
}

// ---------- Toast ----------
let toastTimer

function toast(message, kind = 'info') {
  const region = $('#toasts')
  const el = document.createElement('div')
  el.className = `toast toast--${kind}`
  el.textContent = message
  region.replaceChildren(el)
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => region.replaceChildren(), 4500)
}

// ---------- Modal (native <dialog>) ----------
const modalEl = $('#modal')

function openModal(title, html) {
  modalEl.setAttribute('aria-label', title)
  modalEl.innerHTML = `<div class="modal__body"><h2 class="modal__title">${esc(title)}</h2>${html}</div>`
  if (!modalEl.open) modalEl.showModal()
  return modalEl
}

function closeModal() {
  if (modalEl.open) modalEl.close()
}

modalEl.addEventListener('close', () => {
  modalEl.innerHTML = ''
})

// clicking the dimmed area outside the dialog closes it
modalEl.addEventListener('click', (e) => {
  if (e.target === modalEl) closeModal()
})
