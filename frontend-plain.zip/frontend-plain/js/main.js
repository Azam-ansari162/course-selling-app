// ---------- Routes ----------
// `auth`: needs that role signed in.  `guest`: skip if already signed in.
const ROUTES = {
  '/': { area: 'store', page: pageCatalog },
  '/signin': { area: 'store', guest: true, page: (v) => pageAuth(v, 'user', 'signin') },
  '/signup': { area: 'store', guest: true, page: (v) => pageAuth(v, 'user', 'signup') },
  '/my-courses': { area: 'store', auth: 'user', page: pageMyCourses },
  '/admin': { area: 'admin', auth: 'admin', page: pageDashboard },
  '/admin/signin': { area: 'admin', guest: true, page: (v) => pageAuth(v, 'admin', 'signin') },
  '/admin/signup': { area: 'admin', guest: true, page: (v) => pageAuth(v, 'admin', 'signup') },
}

let renderId = 0
let currentArea = 'store'
let afterAuth = null // where to go once the person has signed in

function currentPath() {
  return (location.hash.slice(1) || '/').split('?')[0]
}

function navigate(hash) {
  if ((location.hash || '#/') === hash) render()
  else location.hash = hash
}

function setAfterAuth(hash) {
  afterAuth = hash
}

function takeAfterAuth(role) {
  const home = role === 'admin' ? '#/admin' : '#/'
  const target = afterAuth && afterAuth.startsWith('#/admin') === (role === 'admin') ? afterAuth : home
  afterAuth = null
  return target
}

function signOut(role) {
  clearToken(role)
  navigate(role === 'admin' ? '#/admin/signin' : '#/')
}

// The token was rejected: send the person to the sign-in page and come back after.
function handleAuthError(err, role) {
  if (!err.session) return false
  clearToken(role)
  toast(err.message, 'error')
  setAfterAuth(location.hash)
  navigate(role === 'admin' ? '#/admin/signin' : '#/signin')
  return true
}

// ---------- Header and footer ----------
function brandMark() {
  return `<svg class="brand__mark" viewBox="0 0 28 28" aria-hidden="true">
    <rect width="13" height="13" fill="#3B4CF0" /><circle cx="21" cy="7" r="7" fill="#FFB627" />
    <path d="M0 28h13V15z" fill="#F0553F" /><path d="M15 15h13v13z" fill="#1FA98B" /></svg>`
}

function renderChrome(area, path) {
  const isAdmin = area === 'admin'
  const role = isAdmin ? 'admin' : 'user'
  const signedIn = Boolean(getToken(role))
  const link = (href, label, active) => `<a class="nav__link${active ? ' nav__link--active' : ''}" href="${href}">${label}</a>`

  let nav = ''
  if (isAdmin) {
    if (signedIn) nav = link('#/admin', 'Your courses', path === '/admin')
  } else {
    nav = link('#/', 'Courses', path === '/')
    if (signedIn) nav += link('#/my-courses', 'My learning', path === '/my-courses')
  }

  const actions = signedIn
    ? '<button type="button" class="btn btn--quiet" id="signout">Sign out</button>'
    : `${link(isAdmin ? '#/admin/signin' : '#/signin', 'Sign in', false)}
       <a href="${isAdmin ? '#/admin/signup' : '#/signup'}" class="btn btn--primary">Create account</a>`

  $('#header').innerHTML = `
    <a href="${isAdmin ? '#/admin' : '#/'}" class="brand">${brandMark()}<span>Lectern</span>${isAdmin ? '<span class="badge">Instructor</span>' : ''}</a>
    <nav class="nav" aria-label="Main">${nav}</nav>
    <div class="header__actions">${actions}</div>`

  const out = $('#signout')
  if (out) out.onclick = () => signOut(role)

  $('#footer').innerHTML = `<span>Lectern</span>${isAdmin ? '<a href="#/">Back to the course store</a>' : '<a href="#/admin">Teach on Lectern</a>'}`
}

function refreshChrome() {
  renderChrome(currentArea, currentPath())
}

// ---------- Router ----------
function render() {
  const id = ++renderId
  closeModal()

  const path = currentPath()
  const route = ROUTES[path] || { area: 'store', page: pageNotFound }
  const role = route.area === 'admin' ? 'admin' : 'user'

  if (route.auth && !getToken(route.auth)) {
    setAfterAuth('#' + path)
    return navigate(route.auth === 'admin' ? '#/admin/signin' : '#/signin')
  }
  if (route.guest && getToken(role)) return navigate(takeAfterAuth(role))

  currentArea = route.area
  renderChrome(route.area, path)
  const view = $('#view')
  view.innerHTML = ''
  window.scrollTo(0, 0)

  Promise.resolve(route.page(view, { stale: () => id !== renderId })).catch((err) => {
    console.error(err)
    view.innerHTML = '<div class="empty"><h2>Something went wrong</h2><p>Reload the page and try again.</p></div>'
  })
}

window.addEventListener('hashchange', render)
render()
