// ---------- Settings ----------
const API_URL = 'http://localhost:3000' // where your Express backend runs
const CURRENCY = 'INR' // how prices are shown
const LOCALE = 'en-IN'

// ---------- Talking to the backend ----------
class ApiError extends Error {
  constructor(message, { status = 0, session = false, body = '' } = {}) {
    super(message)
    this.status = status
    this.session = session // the token was missing, invalid or expired
    this.body = body // raw response text, for callers that need to inspect it
  }
}

// jwt.verify() throws inside the backend middlewares, so Express answers with a
// 500 error page that mentions JsonWebTokenError instead of a clean 401.
const SESSION_PATTERN = /JsonWebTokenError|TokenExpiredError|NotBeforeError|invalid token/i

async function request(path, { method = 'GET', body, headers = {} } = {}) {
  let res
  try {
    res = await fetch(API_URL + path, {
      method,
      headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...headers },
      body: body ? JSON.stringify(body) : undefined,
    })
  } catch {
    throw new ApiError(`Can't reach the server at ${API_URL}. Check that the backend is running.`)
  }

  const text = await res.text()
  let data = null
  try {
    data = JSON.parse(text)
  } catch {
    // not JSON (for example an Express error page)
  }

  // The backend uses `res.send(403).json({...})` in several places. In Express 5
  // that responds with status 200 and the bare number 403 as the body.
  if (typeof data === 'number') {
    throw new ApiError('The server rejected this request.', { status: data, body: text })
  }

  if (!res.ok) {
    if (res.status === 401 || SESSION_PATTERN.test(text)) {
      throw new ApiError('Your session has expired. Sign in again.', { status: res.status, session: true, body: text })
    }
    throw new ApiError((data && data.msg) || `Something went wrong (${res.status}).`, { status: res.status, body: text })
  }

  return data
}

// ---------- Sign-in tokens ----------
// Users and admins are separate accounts with separate JWT secrets on the
// backend, so each role keeps its own token.
const STORAGE_KEY = { user: 'lectern.userToken', admin: 'lectern.adminToken' }
// Header names the backend middlewares read the token from.
const TOKEN_HEADER = { user: 'token', admin: 'admin_token' }

function getToken(role) {
  try {
    return localStorage.getItem(STORAGE_KEY[role])
  } catch {
    return null
  }
}

function setToken(role, token) {
  try {
    localStorage.setItem(STORAGE_KEY[role], token)
  } catch {
    // storage unavailable
  }
}

function clearToken(role) {
  try {
    localStorage.removeItem(STORAGE_KEY[role])
  } catch {
    // ignore
  }
}

// The admin token carries the admin's _id. Reading it lets the dashboard show
// only the courses that admin created, since the API has no "my courses" route.
function adminId() {
  try {
    const payload = getToken('admin').split('.')[1].replace(/-/g, '+').replace(/_/g, '/')
    return JSON.parse(atob(payload))._id || null
  } catch {
    return null
  }
}

// A request that sends the token for `role`. If the backend rejects the token,
// it is cleared, and the error comes back with err.session === true.
async function authed(role, path, options = {}) {
  const token = getToken(role)
  try {
    return await request(path, { ...options, headers: token ? { [TOKEN_HEADER[role]]: token } : {} })
  } catch (err) {
    if (err.session) clearToken(role)
    throw err
  }
}
