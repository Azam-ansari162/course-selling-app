// Each page function draws into `view`. `ctx.stale()` becomes true when the
// person has moved to another page, so slow responses don't draw over it.

function pageHead(title, extra = '') {
  return `<div class="page-head"><h1 class="page-head__title">${esc(title)}</h1>${extra}</div>`
}

function skeletonRows(n = 3) {
  return `<div class="rows" aria-busy="true" aria-label="Loading">${'<div class="row row--skeleton"></div>'.repeat(n)}</div>`
}

function emptyState(title, text, actionHTML = '') {
  return `<div class="empty"><h2>${esc(title)}</h2><p>${esc(text)}</p>${actionHTML}</div>`
}

// ======================================================================
// Course store
// ======================================================================
const SORTS = {
  newest: 'Newest first',
  'price-asc': 'Price: low to high',
  'price-desc': 'Price: high to low',
  name: 'Name: A to Z',
}

async function pageCatalog(view, ctx) {
  view.innerHTML = `
    <section class="hero">
      <h1 class="hero__title">What do you want to learn?</h1>
      <div class="search">
        <svg class="search__icon" viewBox="0 0 24 24" aria-hidden="true">
          <circle cx="11" cy="11" r="7" fill="none" stroke="currentColor" stroke-width="2"></circle>
          <path d="M20 20l-4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round"></path>
        </svg>
        <input type="search" class="search__input" placeholder="Search by title or topic" aria-label="Search courses" autocomplete="off" />
      </div>
    </section>
    <div id="catalog"></div>`

  const box = $('#catalog', view)
  const input = $('.search__input', view)
  let courses = null // null while loading
  let error = ''
  let sort = 'newest'
  let owned = new Set() // ids of courses the signed-in user already bought

  function card(c) {
    const action = owned.has(c._id)
      ? `<a href="#/my-courses" class="btn btn--quiet">In My learning</a>`
      : `<button type="button" class="btn btn--primary" data-buy="${esc(c._id)}">${isFree(c.price) ? 'Get' : 'Buy'}</button>`
    return `
      <article class="course-card">
        ${coverSVG(c.course, 'course-card__cover')}
        <div class="course-card__body">
          <h3 class="course-card__title">${esc(c.course)}</h3>
          <p class="course-card__desc">${esc(c.description)}</p>
        </div>
        <div class="course-card__foot">
          <span class="price">${formatPrice(c.price)}</span>
          ${action}
        </div>
      </article>`
  }

  // Redraws only the results, so the search box keeps focus while typing.
  function paintResults() {
    const results = $('#results', box)
    if (!courses || !results) return

    const q = input.value.trim()
    const needle = q.toLowerCase()
    let list = courses.filter(
      (c) => !needle || (c.course || '').toLowerCase().includes(needle) || (c.description || '').toLowerCase().includes(needle),
    )
    if (sort === 'price-asc') list.sort((a, b) => a.price - b.price)
    else if (sort === 'price-desc') list.sort((a, b) => b.price - a.price)
    else if (sort === 'name') list.sort((a, b) => (a.course || '').localeCompare(b.course || ''))
    else list.reverse() // the API returns oldest first

    $('#count', box).textContent = `${list.length} ${list.length === 1 ? 'course' : 'courses'}${q ? ` for “${q}”` : ''}`

    if (list.length === 0) {
      results.innerHTML = emptyState('No matches', `Nothing matches “${q}”. Try a different word.`, '<button type="button" class="btn btn--quiet" id="clear">Clear search</button>')
      $('#clear', results).onclick = () => {
        input.value = ''
        paintResults()
        input.focus()
      }
    } else {
      results.innerHTML = `<div class="grid">${list.map(card).join('')}</div>`
    }
  }

  // Redraws the whole area when the state changes (loading, error, empty, ready).
  function paintShell() {
    if (error) {
      box.innerHTML = emptyState('Couldn’t load courses', error, '<button type="button" class="btn btn--primary" id="retry">Try again</button>')
      $('#retry', box).onclick = load
    } else if (courses === null) {
      box.innerHTML = `<div class="grid" aria-busy="true" aria-label="Loading courses">${'<div class="course-card course-card--skeleton"></div>'.repeat(6)}</div>`
    } else if (courses.length === 0) {
      box.innerHTML = emptyState('No courses yet', 'Nothing has been published so far. Instructors can add the first one.', '<a href="#/admin" class="btn btn--primary">Create a course</a>')
    } else {
      box.innerHTML = `
        <div class="toolbar">
          <p class="toolbar__count" id="count"></p>
          <label class="toolbar__sort">
            <span>Sort by</span>
            <select class="select" id="sort">
              ${Object.entries(SORTS).map(([value, label]) => `<option value="${value}"${value === sort ? ' selected' : ''}>${label}</option>`).join('')}
            </select>
          </label>
        </div>
        <div id="results"></div>`
      $('#sort', box).onchange = (e) => {
        sort = e.target.value
        paintResults()
      }
      paintResults()
    }
  }

  async function load() {
    error = ''
    courses = null
    paintShell()
    try {
      const data = await request('/users/see')
      if (ctx.stale()) return
      courses = (data && data.Courses) || []
    } catch (err) {
      if (ctx.stale()) return
      error = err.message
    }
    paintShell()
  }

  function startPurchase(course) {
    if (!getToken('user')) {
      setAfterAuth('#/')
      navigate('#/signin')
      return
    }

    const free = isFree(course.price)
    openModal(
      free ? 'Get this course?' : 'Buy this course?',
      `<p class="modal__text"><strong>${esc(course.course)}</strong> costs ${formatPrice(course.price)}. It will be added to My learning.</p>
       <div class="modal__actions">
         <button type="button" class="btn btn--quiet" id="cancel">Cancel</button>
         <button type="button" class="btn btn--primary" id="confirm">${free ? 'Get course' : `Buy for ${formatPrice(course.price)}`}</button>
       </div>`,
    )
    $('#cancel', modalEl).onclick = closeModal
    const confirm = $('#confirm', modalEl)
    confirm.onclick = async () => {
      confirm.disabled = true
      confirm.textContent = 'Working…'
      try {
        await authed('user', '/users/purchase', { method: 'POST', body: { course: course.course } })
        owned.add(course._id)
        closeModal()
        toast(`“${course.course}” is now in My learning.`)
        paintResults()
      } catch (err) {
        closeModal()
        toast(err.message, 'error')
        if (err.session) refreshChrome()
      }
    }
  }

  box.addEventListener('click', (e) => {
    const button = e.target.closest('[data-buy]')
    if (!button || !courses) return
    const course = courses.find((c) => c._id === button.dataset.buy)
    if (course) startPurchase(course)
  })
  input.addEventListener('input', paintResults)

  load()

  // Which courses the signed-in user already owns
  if (getToken('user')) {
    authed('user', '/users/purchases')
      .then((data) => {
        if (ctx.stale()) return
        owned = new Set(((data && data.courseData) || []).map((c) => c._id))
        paintResults()
      })
      .catch(() => {
        if (!ctx.stale()) refreshChrome() // token was rejected: browse as a guest
      })
  }
}

// ======================================================================
// Sign in / sign up (users and instructors)
// ======================================================================
const AUTH_COPY = {
  user: {
    prefix: '/users',
    signin: { title: 'Sign in', button: 'Sign in' },
    signup: { title: 'Create your account', button: 'Create account' },
    switchTo: { signin: '#/signup', signup: '#/signin' },
    art: 'learner',
  },
  admin: {
    prefix: '/admin',
    signin: { title: 'Instructor sign in', button: 'Sign in' },
    signup: { title: 'Create an instructor account', button: 'Create account' },
    switchTo: { signin: '#/admin/signup', signup: '#/admin/signin' },
    art: 'instructor',
  },
}

function pageAuth(view, role, mode) {
  const copy = AUTH_COPY[role]
  const isSignup = mode === 'signup'

  view.innerHTML = `
    <div class="auth">
      <div class="auth__art">${coverSVG(copy.art, 'auth__cover')}</div>
      <div class="auth__panel">
        <h1 class="auth__title">${copy[mode].title}</h1>
        <form class="form" id="auth-form">
          ${
            isSignup
              ? `<div class="field-row">
                   <div class="field"><label for="firstName">First name</label><input id="firstName" class="input" autocomplete="given-name" required /></div>
                   <div class="field"><label for="lastName">Last name</label><input id="lastName" class="input" autocomplete="family-name" required /></div>
                 </div>`
              : ''
          }
          <div class="field"><label for="email">Email</label><input id="email" type="email" class="input" autocomplete="email" required /></div>
          <div class="field"><label for="password">Password</label><input id="password" type="password" class="input" autocomplete="${isSignup ? 'new-password' : 'current-password'}" required /></div>
          <p class="notice notice--error" role="alert" id="auth-error" hidden></p>
          <button type="submit" class="btn btn--primary btn--wide" id="auth-submit">${copy[mode].button}</button>
        </form>
        <p class="auth__switch">
          ${isSignup ? 'Already have an account?' : 'New here?'}
          <a href="${copy.switchTo[mode]}">${isSignup ? 'Sign in' : 'Create an account'}</a>
        </p>
        ${role === 'user' ? '<p class="auth__switch">Want to sell courses? <a href="#/admin/signin">Instructor sign in</a></p>' : ''}
      </div>
    </div>`

  const form = $('#auth-form', view)
  const errorEl = $('#auth-error', view)
  const submit = $('#auth-submit', view)

  form.addEventListener('submit', async (e) => {
    e.preventDefault()
    const email = $('#email', view).value.trim()
    const password = $('#password', view).value

    errorEl.hidden = true
    submit.disabled = true
    submit.textContent = 'Please wait…'
    try {
      if (isSignup) {
        await request(`${copy.prefix}/signup`, {
          method: 'POST',
          body: {
            email,
            password,
            firstName: $('#firstName', view).value.trim(),
            lastName: $('#lastName', view).value.trim(),
          },
        })
      }
      const data = await request(`${copy.prefix}/signin`, { method: 'POST', body: { email, password } })
      if (!data || !data.token) throw new ApiError('Incorrect email or password.', { status: 403 })
      setToken(role, data.token)
      navigate(takeAfterAuth(role))
    } catch (err) {
      let message = err.message
      if (isSignup && err.body && err.body.includes('E11000')) message = 'An account with this email already exists. Sign in instead.'
      else if (!isSignup && err.status === 403) message = 'Incorrect email or password.'
      errorEl.textContent = message
      errorEl.hidden = false
      submit.disabled = false
      submit.textContent = copy[mode].button
    }
  })
}

// ======================================================================
// My learning
// ======================================================================
async function pageMyCourses(view, ctx) {
  view.innerHTML = pageHead('My learning') + skeletonRows()

  try {
    const data = await authed('user', '/users/purchases')
    if (ctx.stale()) return

    const courseById = new Map(((data && data.courseData) || []).map((c) => [c._id, c]))
    const purchases = [...((data && data.purchases) || [])].sort((a, b) => new Date(a.timeOfPurchase) - new Date(b.timeOfPurchase))

    // The backend allows buying the same course twice; show each course once.
    const seen = new Set()
    const items = []
    for (const p of purchases) {
      if (seen.has(p.courseId)) continue
      seen.add(p.courseId)
      const course = courseById.get(p.courseId)
      items.push({
        name: course ? course.course : p.course,
        description: course ? course.description : '',
        price: course ? course.price : null,
        boughtAt: p.timeOfPurchase,
        removed: !course,
      })
    }
    items.reverse()

    if (items.length === 0) {
      view.innerHTML = pageHead('My learning') + emptyState('You haven’t bought a course yet', 'Courses you buy show up here.', '<a href="#/" class="btn btn--primary">Browse courses</a>')
      return
    }

    view.innerHTML =
      pageHead('My learning', `<p class="page-head__meta">${items.length} ${items.length === 1 ? 'course' : 'courses'}</p>`) +
      `<ul class="rows">${items
        .map(
          (item) => `
        <li class="row">
          ${coverSVG(item.name, 'row__cover')}
          <div class="row__main">
            <h2 class="row__title">${esc(item.name)}</h2>
            <p class="row__desc">${item.removed ? 'The instructor has removed this course from the store.' : esc(item.description)}</p>
          </div>
          <div class="row__side">
            <span class="row__meta">Bought ${formatDate(item.boughtAt)}</span>
            ${item.removed ? '' : `<span class="price price--small">${formatPrice(item.price)}</span>`}
          </div>
        </li>`,
        )
        .join('')}</ul>`
  } catch (err) {
    if (ctx.stale() || handleAuthError(err, 'user')) return
    view.innerHTML = pageHead('My learning') + emptyState('Couldn’t load your courses', err.message)
  }
}

// ======================================================================
// Instructor dashboard
// ======================================================================
async function pageDashboard(view, ctx) {
  let courses = null // null while loading
  let error = ''

  function paint() {
    const head = pageHead('Your courses', '<button type="button" class="btn btn--primary" id="new-course">New course</button>')
    let body

    if (error) {
      body = emptyState('Couldn’t load your courses', error, '<button type="button" class="btn btn--primary" id="retry">Try again</button>')
    } else if (courses === null) {
      body = skeletonRows()
    } else if (courses.length === 0) {
      body = emptyState('You haven’t created a course yet', 'Courses you create appear in the store as soon as you save them.', '<button type="button" class="btn btn--primary" id="first-course">Create your first course</button>')
    } else {
      body = `<ul class="rows">${courses
        .map(
          (c) => `
        <li class="row row--admin">
          ${coverSVG(c.course, 'row__cover')}
          <div class="row__main">
            <h2 class="row__title">${esc(c.course)}</h2>
            <p class="row__desc">${esc(c.description)}</p>
          </div>
          <div class="row__side">
            <span class="price price--small">${formatPrice(c.price)}</span>
            <div class="row__actions">
              <button type="button" class="btn btn--quiet btn--small" data-edit="${esc(c._id)}">Edit</button>
              <button type="button" class="btn btn--danger-quiet btn--small" data-delete="${esc(c._id)}">Delete</button>
            </div>
          </div>
        </li>`,
        )
        .join('')}</ul>`
    }

    view.innerHTML = head + body

    $('#new-course', view).onclick = () => openForm(null)
    const first = $('#first-course', view)
    if (first) first.onclick = () => openForm(null)
    const retry = $('#retry', view)
    if (retry) retry.onclick = load
    view.querySelectorAll('[data-edit]').forEach((b) => {
      b.onclick = () => openForm(courses.find((c) => c._id === b.dataset.edit))
    })
    view.querySelectorAll('[data-delete]').forEach((b) => {
      b.onclick = () => openDelete(courses.find((c) => c._id === b.dataset.delete))
    })
  }

  // There is no "my courses" endpoint, so load the public list and keep the ones this admin created.
  async function load() {
    error = ''
    courses = null
    paint()
    try {
      const data = await request('/users/see')
      if (ctx.stale()) return
      const me = adminId()
      courses = ((data && data.Courses) || []).filter((c) => c.creatorId === me).reverse()
    } catch (err) {
      if (ctx.stale()) return
      error = err.message
    }
    paint()
  }

  function openForm(course) {
    const isEdit = Boolean(course)
    openModal(
      isEdit ? 'Edit course' : 'New course',
      `<form class="form" id="course-form">
         <div class="field"><label for="course">Course name</label><input id="course" class="input" value="${esc(isEdit ? course.course : '')}" required /></div>
         <div class="field"><label for="price">Price (${CURRENCY})</label><input id="price" type="number" min="0" step="any" inputmode="decimal" class="input" value="${esc(isEdit ? course.price : '')}" required /></div>
         <div class="field"><label for="description">Description</label><textarea id="description" class="input input--area" rows="5" required>${esc(isEdit ? course.description : '')}</textarea></div>
         <p class="notice notice--error" role="alert" id="form-error" hidden></p>
         <div class="modal__actions">
           <button type="button" class="btn btn--quiet" id="cancel">Cancel</button>
           <button type="submit" class="btn btn--primary" id="save">${isEdit ? 'Save changes' : 'Create course'}</button>
         </div>
       </form>`,
    )

    const form = $('#course-form', modalEl)
    const errorEl = $('#form-error', modalEl)
    const save = $('#save', modalEl)
    const fail = (message) => {
      errorEl.textContent = message
      errorEl.hidden = false
    }
    $('#cancel', modalEl).onclick = closeModal

    form.addEventListener('submit', async (e) => {
      e.preventDefault()
      const name = $('#course', modalEl).value.trim()
      const description = $('#description', modalEl).value.trim()
      const rawPrice = $('#price', modalEl).value
      const price = Number(rawPrice)

      if (!name || !description) return fail('Add a course name and a description.')
      if (rawPrice === '' || !Number.isFinite(price) || price < 0) return fail('Enter a price of 0 or more.')

      errorEl.hidden = true
      save.disabled = true
      save.textContent = 'Saving…'
      try {
        if (isEdit) {
          await authed('admin', '/course/update', { method: 'PUT', body: { courseId: course._id, course: name, price, description } })
        } else {
          await authed('admin', '/course/create', { method: 'POST', body: { course: name, price, description } })
        }
        closeModal()
        toast(isEdit ? 'Changes saved.' : 'Course created.')
        load()
      } catch (err) {
        if (err.session) {
          closeModal()
          handleAuthError(err, 'admin')
          return
        }
        fail(err.status === 403 ? 'A course with this name already exists.' : err.message)
        save.disabled = false
        save.textContent = isEdit ? 'Save changes' : 'Create course'
      }
    })
  }

  function openDelete(course) {
    openModal(
      'Delete this course?',
      `<p class="modal__text"><strong>${esc(course.course)}</strong> will be removed from the store. Students who already bought it will see it marked as removed.</p>
       <div class="modal__actions">
         <button type="button" class="btn btn--quiet" id="cancel">Cancel</button>
         <button type="button" class="btn btn--danger" id="confirm">Delete course</button>
       </div>`,
    )
    $('#cancel', modalEl).onclick = closeModal
    const confirm = $('#confirm', modalEl)
    confirm.onclick = async () => {
      confirm.disabled = true
      confirm.textContent = 'Deleting…'
      try {
        await authed('admin', '/course/delete', { method: 'DELETE', body: { course: course.course } })
        toast('Course deleted.')
      } catch (err) {
        if (err.session) {
          closeModal()
          handleAuthError(err, 'admin')
          return
        }
        toast(err.status === 403 ? 'That course no longer exists.' : err.message, 'error')
      }
      closeModal()
      load()
    }
  }

  load()
}

// ======================================================================
function pageNotFound(view) {
  view.innerHTML = `<div class="empty"><h1>Page not found</h1><p>That address doesn’t lead anywhere.</p><a href="#/" class="btn btn--primary">Go to courses</a></div>`
}
