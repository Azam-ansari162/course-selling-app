// The API has no course images, so every course gets a generated cover: a grid
// of geometric tiles seeded from the course name. Same name, same cover.
const COVER_COLORS = ['#3B4CF0', '#FFB627', '#F0553F', '#1FA98B', '#14213D', '#E8ECF6']
const COVER_SHAPES = ['circle', 'quarter', 'quarter', 'half', 'square', 'triangle', 'none']
const TILE = 60
const TILE_COLS = 4
const TILE_ROWS = 3

function seedFrom(text) {
  let h = 2166136261
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  return h >>> 0
}

function seededRandom(seed) {
  return function () {
    seed = (seed + 0x6d2b79f5) | 0
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function tileShape(shape, x, y, turns, fill) {
  const half = TILE / 2
  const cx = x + half
  const cy = y + half
  const rotate = `transform="rotate(${turns * 90} ${cx} ${cy})"`

  switch (shape) {
    case 'circle':
      return `<circle cx="${cx}" cy="${cy}" r="${half * 0.8}" fill="${fill}"/>`
    case 'quarter':
      return `<path d="M${x} ${y}H${x + TILE}A${TILE} ${TILE} 0 0 1 ${x} ${y + TILE}Z" fill="${fill}" ${rotate}/>`
    case 'half':
      return `<path d="M${x} ${y}A${half} ${half} 0 0 1 ${x} ${y + TILE}Z" fill="${fill}" ${rotate}/>`
    case 'square':
      return `<rect x="${x + TILE * 0.2}" y="${y + TILE * 0.2}" width="${TILE * 0.6}" height="${TILE * 0.6}" fill="${fill}"/>`
    case 'triangle':
      return `<path d="M${x} ${y + TILE}H${x + TILE}V${y}Z" fill="${fill}" ${rotate}/>`
    default:
      return ''
  }
}

// Returns an <svg> string for a course name.
function coverSVG(name, className) {
  const random = seededRandom(seedFrom(String(name || '')))
  const pick = (list) => list[Math.floor(random() * list.length)]

  // Three colours per course
  const pool = [...COVER_COLORS]
  const palette = []
  while (palette.length < 3) palette.push(pool.splice(Math.floor(random() * pool.length), 1)[0])

  let tiles = ''
  for (let row = 0; row < TILE_ROWS; row++) {
    for (let col = 0; col < TILE_COLS; col++) {
      const x = col * TILE
      const y = row * TILE
      const bg = pick(palette)
      const fg = pick(palette.filter((c) => c !== bg))
      const shape = pick(COVER_SHAPES)
      const turns = Math.floor(random() * 4)
      tiles += `<rect x="${x}" y="${y}" width="${TILE + 0.5}" height="${TILE + 0.5}" fill="${bg}"/>` + tileShape(shape, x, y, turns, fg)
    }
  }

  return `<svg class="${className}" viewBox="0 0 ${TILE_COLS * TILE} ${TILE_ROWS * TILE}" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false">${tiles}</svg>`
}
